<?php
/**
 * Template Name: Custom Template
 */

get_header();
?>
    <section id="primary" class="content-area" style="width: 100%;">
        <?php the_content();?>
    </section>

<?php
get_footer();
