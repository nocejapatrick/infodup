<!-- <div class="info-footer-custom">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-12 my-3 my-md-0 px-3 p-md-0">
                <h6 class="font-weight-bold">Informatics Philippines</h6>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            
            <div class="col-md-3 col-12 col-md-offset-3 my-3 my-md-0 px-3 p-md-0">
                <h6 class="font-weight-bold">Navigation</h6>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Programs</a></li>
                    <li><a href="#">Admissions</a></li>
                    <li><a href="#">Corporate Learning</a></li>
                    <li><a href="#">Teachnology</a></li>
                </ul>
            </div>
            <div class="col-md-3 col-12 my-3 my-md-0 px-3 p-md-0">
                <h6 class="font-weight-bold">Sign Up to Our Newsletter</h6>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>
                <form action="/">
                    <div class="form-row">
                        <div class="col-6">
                            <input type="email" class="form-control">
                        </div>
                        <div class="col-6">
                            <input type="submit" class="btn btn-default" value="Subscribe">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> -->