<div class="front-banner">
    <div class="text-center">
         <h1 class="bold-color">See the future.</h1>
         <h1 class="bold-color">Create it with Informatics.</h1>
         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <div class="d-flex front-enroll-btn text-center justify-content-center">
            <a href="#" class="btn btn-primary enroll-now">ENROLL NOW</a>
            <a href="#" class="btn btn-default ml-4">Learn More</a>
        </div>
    </div>
</div>