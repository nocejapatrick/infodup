<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <div class="carousel-title-container">
        <div class="container-fluid pt-3 admission-title-wrap">
            <div class="row">
                <div class="col-md-7 col-sm-12 mt-md-5 ml-md-5">
                     <div class="carousel-title white">
                        INFORMATICS GIVES YOU THE TECH ADVANTAGE.
                    </div>
                    <div class="carousel-sub-title mt-2 white">
                    It’s education with an I.T. factor. The careers of tomorrow are what we prepare you for today. Integrating IT into your discipline will enable you to find your place in a tech-driven world, no matter which industry you choose.
                    </div>
<!-- 					<div class='mt-2 text-md-left mb-5'>
						<button id="inquire-now" type="button" class="btn btn-informatics-blue no-border my-btn-style mt-4" onclick="window.location.href = '/contact-us/'">INQUIRE NOW</button>
					</div> -->
                </div>
            </div>
        </div>
</div>
  <div class="carousel-inner">
    <div class="carousel-item active">
		 <source srcset="/wp-content/uploads/2020/08/Slider-03-min-2-min-600x267.jpg" media="(max-width: 500px)">
      <img class="d-block w-100" src="/wp-content/uploads/2020/08/Slider-03-min-2-min.jpg" alt="First slide">
    </div>
  </div>
</div>