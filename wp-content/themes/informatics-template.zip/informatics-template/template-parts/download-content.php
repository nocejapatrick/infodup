<div class="container-fluid position-relative">
    <div class="row">
        <div class="col-md-12 bg-admission position-relative pt-4 pb-4 margin-negative">
            <div class="container">
            <div class="back-white"></div>
                <div class="row">
                    <div class="col-md-12 text-center p-md-5">
                        <button type="button" class="btn btn-informatics-blue downloads-btn btn-lg font-weight-bold mr-md-5" onclick="window.open('/admissions/download-application-form/')">DOWNLOAD APPLICATION FORM</button>
                    <button type="button" class="btn btn-informatics-blue downloads-btn btn-lg mt-3 ml-md-2 mt-sm-0 font-weight-bold" onclick=" window.open('https://www.informatics.edu.ph/apply-online/','_blank')">APPLY ONLINE</button>
					</div>
                </div>
             </div>
        </div>
    </div>
</div>